# ECON_5100_18FQ_Group_5

Statistical Analysis of Agricultural inputs using data from GLSS4

Group 5
Sanyukta Ghai
Sourabh Gupta
Nancy Jain
Ankita Pathak
