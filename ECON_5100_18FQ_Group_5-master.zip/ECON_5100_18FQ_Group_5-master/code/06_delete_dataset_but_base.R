#rm(list=ls())


# Run after merge_data
rm(list=setdiff(ls(), "base"))

